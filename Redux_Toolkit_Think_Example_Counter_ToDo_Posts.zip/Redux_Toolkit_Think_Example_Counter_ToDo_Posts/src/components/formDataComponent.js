import React, { useState } from "react"
import { ADDFORMDATA, RESETFORMDATA } from "../features/form/formDataSlice"
import { useSelector, useDispatch } from "react-redux"
import { FormControl } from "@mui/material"

const FormDataComponent = () => {
  const [nameValue, setNameValue] = useState("")
  const [salaryValue, setSalaryValue] = useState("")
  const formDataList = useSelector((state) => state.formData.formDataList)
  const dispatch = useDispatch()

  // const resetToDos = () => {
  //   setToDoItem("")
  //   dispatch(RESETTODO())
  // }

  return (
    <>
      <hr />
      <p>{JSON.stringify(formDataList)}</p>
      <FormControl>
        <input type="text" value={nameValue} onChange={(e) => setNameValue(e.target.value)} />
        <input type="text" value={salaryValue} onChange={(e) => setSalaryValue(e.target.value)} />
        <div>
          <button onClick={() => dispatch(ADDFORMDATA({ name: nameValue, salary: salaryValue }))}>Add Form data</button>
          <button onClick={() => dispatch(RESETFORMDATA())}>Reset Form Data</button>
        </div>
      </FormControl>
    </>
  )
}

export default FormDataComponent
