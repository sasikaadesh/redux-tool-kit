import { createSlice, createAsyncThunk } from "@reduxjs/toolkit"

const initialState = {
  entities: [],
  loading: false,
}

export const getPosts = createAsyncThunk("posts/getPosts", async (thunkAPI) => {
  const res = await fetch("https://jsonplaceholder.typicode.com/posts").then((data) => data.json())
  return res
})

// export const getPosts = createAsyncThunk("posts/getPosts", async (thunkAPI, { rejectWithValue }) => {
//   try {
//     const res = await fetch("https://jsonplaceholder.typicode.com/postsa").then((data) => data.json())
//     return res
//   } catch (err) {
//     // You can choose to use the message attached to err or write a custom error
//     // console.log("rejected")
//     return rejectWithValue("Opps there seems to be an error")
//   }
// })

// export const getPosts = createAsyncThunk("posts/getPosts", async (post, { rejectWithValue }) => {
//   try {
//     const response = await fetch("https://jsonplaceholder.typicode.com/posts", {
//       method: "POST",
//       body: JSON.stringify(post),
//       header: {
//         "Content-Type": "application/json",
//       },
//     })
//     const data = await response.json()
//     return data
//   } catch (err) {
//     // You can choose to use the message attached to err or write a custom error
//     return rejectWithValue("Opps there seems to be an error")
//   }
// })

export const PostSlice = createSlice({
  name: "posts",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(getPosts.pending, (state) => {
      state.loading = true
    })
    builder.addCase(getPosts.fulfilled, (state, { payload }) => {
      state.loading = false
      state.entities = payload
    })
    builder.addCase(getPosts.rejected, (state, { payload }) => {
      state.loading = false
      console.log("rejected", payload)
    })
  },
})

export const PostReducer = PostSlice.reducer

// export default postSlice.reducer
