import { useState, useEffect } from "react"
import "./App.css"
import { ThemeProvider, createTheme } from "@mui/material/styles"
import { Switch } from "@mui/material"
import CssBaseline from "@mui/material/CssBaseline"
import Box from "@mui/material/Box"
import Counter from "./components/Counter"
import ToDoComponent from "./components/ToDoComponent"
import FormDataComponent from "./components/formDataComponent"

import { useDispatch, useSelector } from "react-redux"
import { getPosts } from "./Thunk/posts/PostSlice"

// const darkTheme = createTheme({
//   palette: {
//     mode: theme ? "dark" : "light",
//     primary: {
//       main: "#1ca3ec",
//       light: "#77c8f4",
//       dark: "#146bad",
//       contrastText: "#d2edfb",
//     },
//     secondary: {
//       main: "#45a969",
//       light: "#a2d4b4",
//       dark: "#164728",
//       contrastText: "#d1ead9",
//     },
//   },
// })

// Define theme settings
const light = {
  palette: {
    mode: "light",
    primary: {
      main: "#1ca3ec",
      light: "#77c8f4",
      dark: "#146bad",
      contrastText: "#d2edfb",
    },
    secondary: {
      main: "#45a969",
      light: "#a2d4b4",
      dark: "#164728",
      contrastText: "#d1ead9",
    },
  },
}

const dark = {
  palette: {
    mode: "dark",
  },
}

function App() {
  // const [theme, settheme] = useState(false)

  // const handleChange = (event) => {
  //   settheme(event.target.checked)
  // }
  const [isDarkTheme, setIsDarkTheme] = useState(false)

  const dispatch = useDispatch()
  const { entities, loading } = useSelector((state) => state.posts)

  // const stateThunk = useSelector((state) => state.posts.posts)

  useEffect(() => {
    // console.log("stateThunk", stateThunk)
    dispatch(getPosts())
  }, [])

  // This function is triggered when the Switch component is toggled
  const changeTheme = () => {
    setIsDarkTheme(!isDarkTheme)
  }

  // if (loading) return <p>Loading...</p>

  return (
    <div className="App">
      <ThemeProvider theme={isDarkTheme ? createTheme(dark) : createTheme(light)}>
        <CssBaseline />
        <div className="box">
          <div className="row">
            <label>Dark Mode</label>
            {/* <Switch checked={theme} color="success" onChange={handleChange} /> */}
            <Switch checked={isDarkTheme} onChange={changeTheme} />
          </div>
          <div className="row">
            <div className="cell">
              <Box
                sx={{
                  width: 300,
                  height: "auto",
                  backgroundColor: "primary.dark",
                  // "&:hover": {
                  //   backgroundColor: "primary.main",
                  //   opacity: [0.9, 0.8, 0.7],
                  // },
                  borderRadius: "5px",
                  marginTop: 1,
                  padding: "20px",
                }}
              >
                <Counter />
                <ToDoComponent />
                <FormDataComponent />
              </Box>
            </div>
            <div className="cell">
              <div>
                <h2>Blog Posts</h2>
                {entities.map((post) => (
                  <p key={post.id}>{post.title}</p>
                ))}
              </div>
            </div>
          </div>
        </div>
      </ThemeProvider>
    </div>
  )
}

export default App
