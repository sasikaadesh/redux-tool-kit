import { createSlice } from "@reduxjs/toolkit"

const initialState = {
  formDataList: [
    {
      name: "",
      salary: "",
    },
  ],
}

export const formDataSlice = createSlice({
  name: "formData",
  initialState,
  reducers: {
    ADDFORMDATA: (state, action) => {
      state.formDataList.push(action.payload)
    },
    RESETFORMDATA: (state) => {
      state.formDataList = [
        {
          name: "",
          salary: "",
        },
      ]
    },
  },
})

export const { ADDFORMDATA, RESETFORMDATA } = formDataSlice.actions

export default formDataSlice.reducer
